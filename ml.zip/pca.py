
import numpy as np
import matplotlib.pyplot as plt

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# 1. Create a simple dataset with 3 features
X = np.array([
    [2, 3, 4],
    [3, 4, 5],
    [4, 5, 6],
    [5, 6, 7],
    [6, 7, 8],
    [7, 8, 9],
    [8, 9, 10],
    [9, 10, 11]
])

# 2. Standardize the dataset
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 3. Apply PCA and reduce to 2 components
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# 4. Print transformed data
print("Original Shape:", X.shape)
print("Reduced Shape:", X_pca.shape)
print("\nTransformed Data:\n", X_pca)

# 5. Print PCA performance metrics
print("\nExplained Variance Ratio:",
      pca.explained_variance_ratio_)

print("Total Variance Retained:",
      sum(pca.explained_variance_ratio_))

# 6. Plot the reduced data
plt.figure(figsize=(8, 5))
plt.scatter(X_pca[:, 0], X_pca[:, 1], color="blue")

plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA - Dimensionality Reduction")
plt.grid(True)
plt.show()

# 7. Plot explained variance
plt.figure(figsize=(8, 5))
plt.bar(
    ["PC1", "PC2"],
    pca.explained_variance_ratio_
)

plt.xlabel("Principal Components")
plt.ylabel("Explained Variance Ratio")
plt.title("PCA Explained Variance")
plt.show()
