
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score
from sklearn.metrics import classification_report

# 1. Create a simple dataset
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

# 2. Split the dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# 3. Create and train the SVM model
model = SVC(kernel="linear")
model.fit(X_train, y_train)

# 4. Make predictions
y_pred = model.predict(X_test)

# 5. Print model performance metrics
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, zero_division=0))
print("Recall:", recall_score(y_test, y_pred, zero_division=0))
print("F1 Score:", f1_score(y_test, y_pred, zero_division=0))

print("\nClassification Report:\n")
print(classification_report(y_test, y_pred, zero_division=0))

# 6. Plot actual data and decision boundary
X_plot = np.linspace(0, 11, 200).reshape(-1, 1)
y_plot = model.predict(X_plot)

plt.scatter(X, y, color="blue", label="Actual Data")
plt.plot(X_plot, y_plot, color="red", label="Decision Boundary")

# Highlight support vectors
plt.scatter(
    model.support_vectors_,
    model.predict(model.support_vectors_),
    s=150,
    facecolors="none",
    edgecolors="green",
    label="Support Vectors"
)

plt.xlabel("Study Hours")
plt.ylabel("Class (0 = Fail, 1 = Pass)")
plt.title("Support Vector Machine Classification")
plt.yticks([0, 1])
plt.legend()
plt.grid(True)
plt.show()
