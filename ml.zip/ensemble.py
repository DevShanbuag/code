
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier

from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score

# 1. Create a simple dataset
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

# 2. Split the dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# 3. Create ensemble models
models = {
    "Random Forest": RandomForestClassifier(
        n_estimators=50, random_state=42
    ),
    "Bagging": BaggingClassifier(
        estimator=DecisionTreeClassifier(),
        n_estimators=50, random_state=42
    ),
    "AdaBoost": AdaBoostClassifier(
        n_estimators=50, random_state=42
    ),
    "Gradient Boosting": GradientBoostingClassifier(
        n_estimators=50, random_state=42
    )
}

# Store accuracy for comparison
accuracies = []

# 4. Train, predict and evaluate each model
for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)

    print("\nModel:", name)
    print("Accuracy:", accuracy)
    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, zero_division=0))
    print("Recall:", recall_score(y_test, y_pred, zero_division=0))
    print("F1 Score:", f1_score(y_test, y_pred, zero_division=0))

# 5. Plot accuracy comparison
plt.figure(figsize=(8, 5))
plt.bar(models.keys(), accuracies)

plt.xlabel("Ensemble Models")
plt.ylabel("Accuracy")
plt.title("Ensemble Model Accuracy Comparison")
plt.ylim(0, 1.1)
plt.xticks(rotation=15)
plt.grid(axis="y")
plt.tight_layout()
plt.show()

# 6. Plot predictions of each model
X_plot = np.linspace(0, 11, 200).reshape(-1, 1)

plt.figure(figsize=(9, 5))
plt.scatter(X, y, color="black", label="Actual Data")

for name, model in models.items():
    plt.plot(
        X_plot.ravel(),
        model.predict(X_plot),
        label=name
    )

plt.xlabel("Study Hours")
plt.ylabel("Predicted Class")
plt.title("Ensemble Models Prediction Comparison")
plt.yticks([0, 1])
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
