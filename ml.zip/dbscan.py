import numpy as np
import matplotlib.pyplot as plt

from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

X = np.array([
    [1, 2], [1, 3], [2, 2], [2, 3],
    [8, 8], [8, 9], [9, 8], [9, 9],
    [5, 1], [12, 12]
])

model = DBSCAN(eps=1.5, min_samples=2)
labels = model.fit_predict(X)

# 3. Print cluster labels
print("Cluster Labels:", labels)
print("Number of Clusters:", len(set(labels)) - (1 if -1 in labels else 0))
print("Number of Noise Points:", list(labels).count(-1))

clusters = set(labels) - {-1}
mask = labels != -1

if len(clusters) >= 2 and len(set(labels[mask])) < sum(mask):
    score = silhouette_score(X[mask], labels[mask])
    print("Silhouette Score:", score)
else:
    print("Silhouette Score: Not applicable")

# 5. Plot the clusters
plt.figure(figsize=(8, 5))

for label in set(labels):
    points = X[labels == label]

    if label == -1:
        plt.scatter(
            points[:, 0], points[:, 1],
            color="black", marker="x", s=100,
            label="Noise"
        )
    else:
        plt.scatter(
            points[:, 0], points[:, 1],
            s=100, label=f"Cluster {label}"
        )

plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("DBSCAN Clustering")
plt.legend()
plt.grid(True)
plt.show()
